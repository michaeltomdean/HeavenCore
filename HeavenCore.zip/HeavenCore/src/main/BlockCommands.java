package main;


import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;


public class BlockCommands implements Listener {
	@EventHandler(priority = EventPriority.LOWEST)
	public void OnCommandEvent(PlayerCommandPreprocessEvent e) {
		String command = e.getMessage();
		if (command.toLowerCase().startsWith("/pl")){
			e.setCancelled(true);
		}
		
		
	}

}
