package main;

import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;






public class MessageCommand implements CommandExecutor {
	private HashMap<UUID, UUID> lastMessage = new HashMap<>();
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (args.length<2){
			return false;
		}
		if (cmd.getName().equalsIgnoreCase("msg")) {
			if(sender instanceof Player) {
				Player player = (Player) sender;
				Player target = Bukkit.getPlayer(args[0]);
				if (target==null) {
					return false;
				}
				if (target.equals(player)) {
					player.sendMessage(ChatColor.RED + "You cannot message yourself");
					return false;
				}
				StringBuilder Message = new StringBuilder();
				for (int i = 1; i < args.length; i++) {
					Message.append(args[i]);
				}
				target.sendMessage(ChatColor.GREEN + "FROM" + ChatColor.GRAY + "(" + ChatColor.LIGHT_PURPLE + player.getDisplayName() + ChatColor.DARK_GRAY + "�" + Message + ChatColor.GRAY + ")");
				player.sendMessage(ChatColor.GREEN + "TO" + ChatColor.GRAY + "(" + ChatColor.LIGHT_PURPLE + target.getDisplayName() + ChatColor.DARK_GRAY + "�" + Message + ChatColor.GRAY + ")");
				lastMessage.put(target.getUniqueId(), player.getUniqueId());
				return true;
			}
			return false;
		}
		if (cmd.getName().equalsIgnoreCase("r")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				Player target = Bukkit.getPlayer(lastMessage.get(player.getUniqueId()));
				if (Bukkit.getPlayer(target.getUniqueId()).isOnline()) {
					target.sendMessage(ChatColor.GREEN + "FROM" + ChatColor.GRAY + "(" + ChatColor.LIGHT_PURPLE + player.getDisplayName() + ChatColor.DARK_GRAY + "�" + args[1] + ChatColor.GRAY + ")");
					player.sendMessage(ChatColor.GREEN + "TO" + ChatColor.GRAY + "(" + ChatColor.LIGHT_PURPLE + target.getDisplayName() + ChatColor.DARK_GRAY + "�" + args[1] + ChatColor.GRAY + ")");
					return true;
				}
				
				return false;
			}
			return false;
		}
		
		return false;

	}

}