package main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class StaffChat implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (args.length <1) {
			return false;
		}
		if(cmd.getName().equalsIgnoreCase("ac") || cmd.getName().equalsIgnoreCase("staffchat")) {
			String allargs = String.join(" ", args);
			if(sender instanceof Player) {
				Player player = (Player) sender;
				if (player.hasPermission("heaven.staff")){
					for (Player anyplayer: Bukkit.getOnlinePlayers()){
						if (anyplayer.hasPermission("heaven.staff")) {
							anyplayer.sendMessage(ChatColor.RED + "Staff Chat" + ChatColor.DARK_GRAY + " � " + ChatColor.RESET + player.getDisplayName() + ": " + ChatColor.WHITE + allargs);
		}

					}
					
				}
			}
		}
		return false;
	}
}
