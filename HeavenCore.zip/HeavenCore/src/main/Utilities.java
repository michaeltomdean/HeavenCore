package main;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Utilities implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("feed")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				player.setFoodLevel(20);
				return true;
			}
		}
		if (cmd.getName().equalsIgnoreCase("heal")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				player.setHealth(20);
				return true;
			}
		}
		return false;
	}

}
