package main;


import org.bukkit.plugin.java.JavaPlugin;

public class MainCore extends JavaPlugin {
    public void onEnable() {
        getCommand("msg").setExecutor(new MessageCommand());
        getCommand("r").setExecutor(new MessageCommand());
        getCommand("ac").setExecutor(new StaffChat());
        getCommand("staffchat").setExecutor(new StaffChat());
        getCommand("heal").setExecutor(new Utilities());
        getCommand("feed").setExecutor(new Utilities());
        getServer().getPluginManager().registerEvents(new BlockCommands(), this);
        getServer().getPluginManager().registerEvents(new PlayerJoinMessages(), this);
        getServer().getPluginManager().registerEvents(new PlayerLeaveMessages(), this);
    }
}
